# Apps From Scratch | Flutter Chat UI Starter Repo

Clone this repo and follow my YouTube video: [Flutter Chat UI Tutorial | Apps From Scratch](https://youtu.be/h-igXZCCrrc)

[Complete Chat UI](https://github.com/MarcusNg/flutter_chat_ui)
